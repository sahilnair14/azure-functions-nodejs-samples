const { app } = require('@azure/functions');

const helloWorld1 = require("./functions/helloworld1")

app.http('helloWorld1',helloWorld1)

app.hook.appStart((context) => {
    // add your logic here
    context.log('App is starting...');
});

app.hook.appTerminate((context) => {
    // add your logic here
    

    context.log('App is terminating...');

});
