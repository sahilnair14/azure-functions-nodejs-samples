module.exports = {
  methods: ['GET', 'POST'],
  authLevel: 'anonymous',
  handler: async (request, context) => {
    context.log('helloWorld1 triggered');
    return { body: 'Hello from helloWorld1!' };
  }
};
